# GoOutWithABang  
Spawns a mine on player and triggers it when they die.  
## Config  
Set true or false for which death type it spawns a mine.  
By default Explosion and Unknown are turned off.
