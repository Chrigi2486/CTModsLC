## v1.0.1 Fixing Non Death mines exploding
- Thanks a lot to Jwaffled for fixing this!

## v1.0.0 Release
- Release

</details>